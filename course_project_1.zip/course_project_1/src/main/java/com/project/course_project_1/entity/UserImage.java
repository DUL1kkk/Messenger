package com.project.course_project_1.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "user_image")
public class UserImage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "user_id")
    private User user;

    @Lob
    private byte[] imageData;

    public Long getId() {
        return id;
    }

    public UserImage setId(Long id) {
        this.id = id;
        return this;
    }

    public User getUser() {
        return user;
    }

    public UserImage setUser(User user) {
        this.user = user;
        return this;
    }

    public byte[] getImageData() {
        return imageData;
    }

    public UserImage setImageData(byte[] imageData) {
        this.imageData = imageData;
        return this;
    }
}
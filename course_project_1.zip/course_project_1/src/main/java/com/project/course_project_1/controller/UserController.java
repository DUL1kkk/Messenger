package com.project.course_project_1.controller;

import com.project.course_project_1.entity.Message;
import com.project.course_project_1.entity.User;
import com.project.course_project_1.service.MessageService;
import com.project.course_project_1.service.UserService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Set;

@Slf4j
@Controller
@RequestMapping("/users")
public class UserController {

    private final UserService userService;
    private final MessageService messageService;

    public UserController(UserService userService, MessageService messageService) {
        this.userService = userService;
        this.messageService = messageService;
    }

    @GetMapping("/main")
    public String showMainUser(Model model, @AuthenticationPrincipal User user) {
        model.addAttribute("user", userService.findUserById(user.getId()));
        model.addAttribute("user_friends", userService.findUserById(user.getId()).getFriends());
        model.addAttribute("login_times", userService.getUserLoginTimes(user.getId()));

        userService.saveUserLoginTimes(user.getId());
        return "main";
    }

    @PostMapping("/image")
    public String uploadUserImage(@RequestParam("file") MultipartFile image,
                                  @AuthenticationPrincipal User user) {

        return "redirect:/users/main";
    }

    @GetMapping("/main/delete/logs")
    public String deleteUsersLogs(@AuthenticationPrincipal User user) {
        user.getLoginTimes().clear();
        userService.saveUser(user);
        return "redirect:/users/main";
    }

    @GetMapping("/main/edit")
    public String editMainUser(@AuthenticationPrincipal User user, Model model) {
        model.addAttribute("user", user);
        return "edit-main-user";
    }

    @PostMapping("/main/edit")
    public String saveMainEdit(@Valid User editedUser, BindingResult bindingResult,
                               @AuthenticationPrincipal User user, Model model) {
        if (userService.existsUserByUsername(editedUser.getUsername())) {
            if (!editedUser.getUsername().equals(user.getUsername())) {
                model.addAttribute("error_message", "Пользователь с таким логином уже существует");
                return "edit-main-user";
            }
        }
        if (bindingResult.hasErrors()) {
            return "edit-main-user";
        } else {
            userService.saveEditedUser(user, editedUser);
            return "redirect:/users/main";
        }
    }

    @GetMapping("/")
    public String allUsers(Model model, @AuthenticationPrincipal User user) {
        model.addAttribute("users", userService.findUsersByIdNotIn(userService.getUsersFriendsIds(user.getId())));
        return "all-users";
    }

    @PostMapping("/{id}")
    public String addFriend(@AuthenticationPrincipal User user, @PathVariable("id") Long newFriendId) {
        userService.addFriend(user.getId(), newFriendId);
        return "redirect:";
    }

    @GetMapping("/search")
    public String getUsersByParam(@RequestParam("searchParam") String searchParam, Model model) {
        Set<User> users = userService.findByParam(searchParam);
        if (users.isEmpty()) {
            model.addAttribute("message", "Нет пользователей удовлетворяющих запросу");
        }
        model.addAttribute("users", users);
        return "all-users";
    }

    @GetMapping("/{id}")
    public String getUser(@PathVariable("id") Long id, Model model) {
        model.addAttribute("user", userService.findUserById(id));
        model.addAttribute("user_friends", userService.findUserById(id).getFriends());
        model.addAttribute("login_times", userService.getUserLoginTimes(id));
        return "user";
    }

    @GetMapping("/{id}/messages")
    public String getMessages(@PathVariable("id") Long id, @AuthenticationPrincipal User user, Model model) {
        List<Message> messages = messageService.getMessagesBetweenUsers(user, userService.findUserById(id));
        model.addAttribute("messages", messages);
        model.addAttribute("receiver", userService.findUserById(id));
        return "messages";
    }

    @PostMapping("/{id}/messages")
    public String sendMessage(@PathVariable("id") Long id, @RequestParam("content") String content,
                              @AuthenticationPrincipal User user) {
        User receiver = userService.findUserById(id);
        messageService.sendMessage(user, receiver, content);
        return "redirect:/users/" + id + "/messages";
    }
}

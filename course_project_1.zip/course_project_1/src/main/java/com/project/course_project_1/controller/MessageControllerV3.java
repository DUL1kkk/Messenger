package com.project.course_project_1.controller;


import com.project.course_project_1.entity.Message;
import com.project.course_project_1.entity.User;
import com.project.course_project_1.service.MessageService;
import com.project.course_project_1.service.UserService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/messages")
public class MessageControllerV3 {

    private final UserService userService;
    private final MessageService messageService;

    public MessageControllerV3(UserService userService, MessageService messageService) {
        this.userService = userService;
        this.messageService = messageService;
    }

    @GetMapping("/users/{id}")
    public String getMessages(@PathVariable Long id, @AuthenticationPrincipal User currentUser, Model model) {
        User receiver = userService.findUserById(id);
        if (receiver == null || receiver.equals(currentUser)) {
            return "redirect:/users/main";
        }
        model.addAttribute("receiver", receiver);
        model.addAttribute("messages", messageService.getMessagesBetweenUsers(currentUser, receiver));
        return "messages";
    }

    @PostMapping("/users/{id}")
    public String sendMessage(@PathVariable Long id, @RequestParam String content, @AuthenticationPrincipal User sender) {
        User receiver = userService.findUserById(id);
        if (receiver != null && !receiver.equals(sender)) {
            messageService.sendMessage(sender, receiver, content);
        }
        return "redirect:/messages/users/" + id;
    }
}

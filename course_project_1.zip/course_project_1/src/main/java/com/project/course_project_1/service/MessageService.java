package com.project.course_project_1.service;

import com.project.course_project_1.entity.Message;
import com.project.course_project_1.entity.User;

import java.util.List;

public interface MessageService {
    void sendMessage(User sender, User receiver, String content);
    List<Message> getMessagesBetweenUsers(User user1, User user2);
}

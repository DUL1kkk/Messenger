package com.project.course_project_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseProject1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
